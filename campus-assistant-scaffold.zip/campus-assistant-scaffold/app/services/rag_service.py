"""
RAG pipeline skeleton over the LASU knowledge base
(handbook, academic calendar, SIWES guidelines, clearance process, etc).

TODO (build day):
    1. Populate app/data/ with the actual source docs (txt/pdf).
    2. Run the ingest endpoint (or ingest.py script) to chunk + embed them.
    3. Tune SYSTEM_PROMPT and chunk size for answer quality.

This uses chromadb's default embedding function so it works fully offline
with no extra API keys — matches the workshop's "offline advantage" angle.
"""
import chromadb
from app.config import settings
from app.services.ollama_client import ollama_client

SYSTEM_PROMPT = """You are the LASU Campus Assistant. Answer ONLY using the
provided context from official LASU documents (handbook, academic calendar,
SIWES guidelines, clearance process, etc). If the answer isn't in the
context, say you don't have that information and suggest where the student
might check (e.g. the relevant office). Be concise and specific.

TODO: refine this prompt during the build — add tone/format guidance,
citation style (e.g. "per the Student Handbook §3.2"), etc.
"""

_client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
_collection = _client.get_or_create_collection(name="lasu_knowledge_base")


def add_documents(chunks: list[str], ids: list[str], metadatas: list[dict] | None = None) -> int:
    """Embed and store chunks. metadatas e.g. [{"source": "handbook", "section": "SIWES"}]"""
    _collection.add(documents=chunks, ids=ids, metadatas=metadatas)
    return len(chunks)


def retrieve(query: str, top_k: int = 4) -> list[dict]:
    results = _collection.query(query_texts=[query], n_results=top_k)
    docs = results.get("documents", [[]])[0]
    metas = results.get("metadatas", [[]])[0]
    return [{"text": d, "metadata": m} for d, m in zip(docs, metas)]


async def answer_query(query: str, top_k: int = 4, history: list[dict] | None = None) -> dict:
    """
    Full RAG: retrieve context, ask Gemma to synthesize an answer.

    history: prior turns from the client, e.g.
        [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]
    Server stays stateless — the frontend owns and resends conversation
    history on every call. Retrieval is still done fresh each turn using
    only the latest query (not the full history) to keep it simple.
    """
    hits = retrieve(query, top_k=top_k)
    context = "\n\n---\n\n".join(h["text"] for h in hits) if hits else "(no matching context found)"

    turn_prompt = f"""Context from LASU documents:
{context}

Student question: {query}

Answer the question using only the context above."""

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(history or [])
    messages.append({"role": "user", "content": turn_prompt})

    answer = await ollama_client.chat(messages=messages)
    return {
        "answer": answer,
        "sources": [h["metadata"] for h in hits],
    }
